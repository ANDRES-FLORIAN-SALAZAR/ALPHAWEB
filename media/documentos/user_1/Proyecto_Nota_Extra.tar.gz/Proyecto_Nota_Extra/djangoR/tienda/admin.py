from django.contrib import admin
from .models import producto

# Register your models here.

class ProductoAdmin(admin.ModelAdmin):
    list_display=(
        "id",
        "nombre",
        "contenido",
        "precio",
        "cantidad",
        "pais",
    )

admin.site.register(producto, ProductoAdmin)