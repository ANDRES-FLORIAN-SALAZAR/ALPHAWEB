from django.db import models

# Create your models here.

class producto(models.Model):
    nombre          = models.CharField(max_length=50)
    contenido       = models.CharField(max_length=1000)    
    precio          = models.FloatField()
    cantidad        = models.PositiveIntegerField()
    pais = models.CharField(max_length=100, blank=True, null=True)  # Nuevo campo