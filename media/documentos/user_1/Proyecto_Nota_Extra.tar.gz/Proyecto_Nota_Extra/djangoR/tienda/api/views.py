from rest_framework.viewsets import ModelViewSet
from tienda.api.serializers import productoSerializer
from tienda.models import producto



class productosViewSet(ModelViewSet):
    serializer_class = productoSerializer
    queryset = producto.objects.all()