from rest_framework import serializers
from tienda.models import (producto)

class productoSerializer(serializers.ModelSerializer):
    class Meta:
        model = producto
        fields = [
            "id",
            "nombre",
            "contenido",
            "precio",
            "cantidad",
        ]