from rest_framework.routers import DefaultRouter
from tienda.api.views import productosViewSet

router_producto = DefaultRouter()

router_producto.register(prefix='producto', basename='producto', viewset=productosViewSet)